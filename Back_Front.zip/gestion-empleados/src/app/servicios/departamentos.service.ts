import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface Departamento {
  departamento_id: number;
  nombre: string;
  ubicacion?: string;
  jefe_departamento?: string;
  extension?: string;
}

@Injectable({
  providedIn: 'root'
})
export class DepartamentosService {
  private apiUrl = 'https://localhost:7002/api/departamentos'; // Ajusta el puerto según tu backend

  constructor(private http: HttpClient) {}

  getDepartamentos(): Observable<Departamento[]> {
    return this.http.get<Departamento[]>(this.apiUrl);
  }

  getDepartamento(id: number): Observable<Departamento> {
    return this.http.get<Departamento>(`${this.apiUrl}/${id}`);
  }

  addDepartamento(dep: Departamento): Observable<Departamento> {
    return this.http.post<Departamento>(this.apiUrl, dep);
  }

  updateDepartamento(id: number, dep: Departamento): Observable<void> {
    return this.http.put<void>(`${this.apiUrl}/${id}`, dep);
  }

  deleteDepartamento(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${id}`);
  }
}