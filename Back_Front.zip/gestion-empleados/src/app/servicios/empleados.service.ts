import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

// Interfaz para tipar los datos de empleados
export interface Empleado {
  empleado_id: number;
  nombre: string;
  apellido: string;
  email: string;
  telefono?: string;
  departamento_id: number;
  departamento?: {
    departamento_id: number;
    nombre: string;
  };
}

@Injectable({
  providedIn: 'root'
})
export class EmpleadosService {
  private apiUrl = 'https://localhost:7002/api/empleados'; // Ajusta el puerto según tu backend

  constructor(private http: HttpClient) {}

  // Obtener todos los empleados
  getEmpleados(): Observable<Empleado[]> {
    return this.http.get<Empleado[]>(this.apiUrl);
  }

  // Obtener un empleado por ID
  getEmpleado(id: number): Observable<Empleado> {
    return this.http.get<Empleado>(`${this.apiUrl}/${id}`);
  }

  // Crear un nuevo empleado
  addEmpleado(empleado: Empleado): Observable<Empleado> {
    return this.http.post<Empleado>(this.apiUrl, empleado);
  }

  // Actualizar un empleado existente
  updateEmpleado(id: number, empleado: Empleado): Observable<void> {
    return this.http.put<void>(`${this.apiUrl}/${id}`, empleado);
  }

  // Eliminar un empleado por ID
  deleteEmpleado(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${id}`);
  }
}