import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { EmpleadosService, Empleado } from '../servicios/empleados.service';

@Component({
  selector: 'app-empleados',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './empleados.component.html',
  styleUrls: ['./empleados.component.css']
})
export class EmpleadosComponent implements OnInit {
  empleados: Empleado[] = [];
  empleadoForm!: FormGroup;
  editMode = false;
  empleadoEditId: number | null = null;

  constructor(
    private empleadosService: EmpleadosService,
    private fb: FormBuilder
  ) {}

  ngOnInit(): void {
    this.cargarEmpleados();
    this.empleadoForm = this.fb.group({
      nombre: ['', Validators.required],
      apellido: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      telefono: [''],
      departamento_id: ['', Validators.required]
    });
  }

  cargarEmpleados(): void {
    this.empleadosService.getEmpleados().subscribe((data: Empleado[]) => {
      this.empleados = data;
    });
  }

  agregarEmpleado(): void {
    if (this.empleadoForm.valid) {
      const nuevoEmpleado: Empleado = this.empleadoForm.value;
      this.empleadosService.addEmpleado(nuevoEmpleado).subscribe(() => {
        this.cargarEmpleados();
        this.empleadoForm.reset();
      });
    }
  }

  editarEmpleado(empleado: Empleado): void {
    this.editMode = true;
    this.empleadoEditId = empleado.empleado_id;
    this.empleadoForm.patchValue(empleado);
  }

  actualizarEmpleado(): void {
    if (this.empleadoForm.valid && this.empleadoEditId !== null) {
      const empleadoActualizado: Empleado = this.empleadoForm.value;
      this.empleadosService.updateEmpleado(this.empleadoEditId, empleadoActualizado).subscribe(() => {
        this.cargarEmpleados();
        this.cancelarEdicion();
      });
    }
  }

  cancelarEdicion(): void {
    this.editMode = false;
    this.empleadoEditId = null;
    this.empleadoForm.reset();
  }

  eliminarEmpleado(id: number): void {
    this.empleadosService.deleteEmpleado(id).subscribe(() => {
      this.cargarEmpleados();
    });
  }
}