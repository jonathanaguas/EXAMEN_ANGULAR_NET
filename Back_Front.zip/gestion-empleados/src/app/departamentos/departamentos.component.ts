import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { DepartamentosService, Departamento } from '../servicios/departamentos.service';

@Component({
  selector: 'app-departamentos',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './departamentos.component.html',
  styleUrls: ['./departamentos.component.css']
})
export class DepartamentosComponent {
  departamentos: Departamento[] = [];
  departamentoForm!: FormGroup;
  editMode = false;
  departamentoEditId: number | null = null;

  constructor(
    private departamentosService: DepartamentosService,
    private fb: FormBuilder
  ) {
    this.departamentoForm = this.fb.group({
      nombre: ['', Validators.required],
      ubicacion: [''],
      jefe_departamento: [''],
      extension: ['']
    });
    this.cargarDepartamentos();
  }

  cargarDepartamentos(): void {
    this.departamentosService.getDepartamentos().subscribe((data: Departamento[]) => {
      this.departamentos = data;
    });
  }

  agregarDepartamento(): void {
    if (this.departamentoForm.valid) {
      const nuevoDepartamento: Departamento = this.departamentoForm.value;
      this.departamentosService.addDepartamento(nuevoDepartamento).subscribe(() => {
        this.cargarDepartamentos();
        this.departamentoForm.reset();
      });
    }
  }

  editarDepartamento(dep: Departamento): void {
    this.editMode = true;
    this.departamentoEditId = dep.departamento_id;
    this.departamentoForm.patchValue(dep);
  }

  actualizarDepartamento(): void {
    if (this.departamentoForm.valid && this.departamentoEditId !== null) {
      const depActualizado: Departamento = this.departamentoForm.value;
      this.departamentosService.updateDepartamento(this.departamentoEditId, depActualizado).subscribe(() => {
        this.cargarDepartamentos();
        this.cancelarEdicion();
      });
    }
  }

  cancelarEdicion(): void {
    this.editMode = false;
    this.departamentoEditId = null;
    this.departamentoForm.reset();
  }

  eliminarDepartamento(id: number): void {
    this.departamentosService.deleteDepartamento(id).subscribe(() => {
      this.cargarDepartamentos();
    });
  }
}