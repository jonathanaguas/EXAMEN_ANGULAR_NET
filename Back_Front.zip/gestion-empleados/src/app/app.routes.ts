import { Routes } from '@angular/router';
import { EmpleadosComponent } from './empleados/empleados.component';
import { DepartamentosComponent } from './departamentos/departamentos.component';

export const routes: Routes = [
  { path: 'empleados', component: EmpleadosComponent },
  { path: 'departamentos', component: DepartamentosComponent },
  { path: '', redirectTo: '/empleados', pathMatch: 'full' }
];